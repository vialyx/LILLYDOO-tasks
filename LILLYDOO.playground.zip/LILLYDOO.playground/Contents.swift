import UIKit

/*
 Task 1
 */

// Additions
typealias User = Any

protocol ProgressType {
    func update(_ p: Double)
}

class LillydooProgress: ProgressType {
    
    static let shared = LillydooProgress()
    
    func update(_ p: Double) {
        print("\(#function): \(p)")
    }
    
}

// Code
typealias TestClassCallback = ()->()

class Class1 {
    
    var progress: ProgressType!
    /*
     `savedCallback` is a class property and overwrites by instance
     It works incorrect in case of more that 1 instance executes `savedCallback()`
     */
    //    static var savedCallback: TestClassCallback!
    // Solution
    private var savedCallback: TestClassCallback!
    
    // `callback` should be marked `@escaping` as it copied to future execution in async way
    func doWorkWithPerson(user: User, callback: @escaping TestClassCallback) {
        //        Class1.savedCallback = callback
        // Solution
        self.savedCallback = callback
        // `self` should be passed into `queue` via capture list to prevent strong references
        DispatchQueue.global(qos: .background).async {
            // Solution
            [weak self] in
            self?.doVeryLongTask(user: user)
        }
    }
    
    private func doVeryLongTask(user: User) {
        /*
         We should avoid using `implementation` directly
         For best testabiity use protocols abstractions
         */
        var p = 0.0
        // Do some actions
        //        LillydooProgress.shared.update(p)
        // Solution
        progress.update(p)
        // Do more actions
        //        LillydooProgress.shared.update(p)
        // Solution
        progress.update(p)
        //        Class1.savedCallback()
        // Solution
        savedCallback?()
    }
    
}

// Mocks
class MockProgress: ProgressType {
    
    var updateCount = 0
    func update(_ p: Double) {
        updateCount += 1
    }
    
}

// Tests
let progress = MockProgress()
let instance1 = Class1()
instance1.progress = progress
let instance2 = Class1()
instance2.progress = progress

instance1.doWorkWithPerson(user: 1) {
    print("instance1 completion")
}
instance2.doWorkWithPerson(user: 2) {
    print("instance2 completion")
}

assert(progress.updateCount == 4)
