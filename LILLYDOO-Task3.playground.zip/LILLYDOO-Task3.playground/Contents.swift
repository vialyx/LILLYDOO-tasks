//: A UIKit based Playground for presenting user interface
  
import UIKit
import PlaygroundSupport

class ShadowView: UIView {
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        configure()
    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        configure()
    }
    
    private func configure() {
        layer.shadowColor = UIColor.black.cgColor
        layer.shadowOpacity = 1
        layer.shadowOffset = .zero
        layer.shadowRadius = 10
    }
    
}

class Label: UILabel {
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        configure()
    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        configure()
    }
    
    private func configure() {
        textAlignment = .center
        textColor = .black
        font = UIFont.systemFont(ofSize: 16, weight: .thin)
    }
    
}

class BorderedButton: UIButton {
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        configure()
    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        configure()
    }
    
    func configure() {
        layer.borderWidth = 1
        layer.borderColor = UIColor.gray.cgColor
        setTitleColor(.gray, for: UIControl.State())
    }
    
}

class FilledButton: BorderedButton {
    
    override func configure() {
        super.configure()
        setTitleColor(.white, for: UIControl.State())
        backgroundColor = .gray
    }
    
}

class MyViewController : UIViewController {
    
    override func loadView() {
        let view = ShadowView(frame: .zero)
        view.translatesAutoresizingMaskIntoConstraints = false
        view.backgroundColor = .white

        let stackV = UIStackView()
        stackV.translatesAutoresizingMaskIntoConstraints = false
        stackV.axis = .vertical
        stackV.spacing = 16
        view.addSubview(stackV)
        NSLayoutConstraint.activate([
            stackV.topAnchor.constraint(equalTo: view.topAnchor, constant: 16),
            stackV.bottomAnchor.constraint(equalTo: view.bottomAnchor, constant: -16),
            stackV.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 16),
            stackV.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -16)
        ])
        
        let titleL = Label()
        titleL.text = NSLocalizedString("Lorem ipsum lorem ipsum", comment: "")
        stackV.addArrangedSubview(titleL)
        
        let approveB = FilledButton()
        approveB.setTitle(NSLocalizedString("Approve", comment: ""), for: UIControl.State())
        approveB.heightAnchor.constraint(equalToConstant: 50).isActive = true
        stackV.addArrangedSubview(approveB)
        
        let cancelB = BorderedButton()
        cancelB.setTitle(NSLocalizedString("Cancel", comment: ""), for: UIControl.State())
        cancelB.heightAnchor.constraint(equalToConstant: 50).isActive = true
        stackV.addArrangedSubview(cancelB)
        
        self.view = view
    }
    
}
// Present the view controller in the Live View window
PlaygroundPage.current.liveView = MyViewController()
